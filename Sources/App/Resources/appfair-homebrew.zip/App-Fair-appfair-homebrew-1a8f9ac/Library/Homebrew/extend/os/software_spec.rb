# typed: strict
# frozen_string_literal: true

require "extend/os/linux/software_spec" if OS.linux?
