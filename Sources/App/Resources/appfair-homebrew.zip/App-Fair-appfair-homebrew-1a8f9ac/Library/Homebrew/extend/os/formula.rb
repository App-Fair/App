# typed: strict
# frozen_string_literal: true

require "extend/os/linux/formula" if OS.linux?
