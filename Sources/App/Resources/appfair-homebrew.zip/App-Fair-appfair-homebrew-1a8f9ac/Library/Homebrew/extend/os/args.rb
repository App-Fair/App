# typed: true
# frozen_string_literal: true

require "extend/os/linux/args" if OS.linux?
